package com.app.arctic;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        /*View.OnClickListener  ls = new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AppMainActivity.class);
                startActivity(intent);  //Loagin화면을 띄운다.
                finish();
            }
        };*/
    }


    public void onClick(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);  //Loagin화면을 띄운다.
    }

    public void btn_sign(View view) {
        Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
        startActivity(intent);  //Loagin화면을 띄운다.
    }
}